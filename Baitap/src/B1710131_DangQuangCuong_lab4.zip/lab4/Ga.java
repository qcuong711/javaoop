package lab4;

public class Ga extends ConVat{
	
	public Ga() {
		super();
	}
	
	@Override
	public void Keu() {
		System.out.println("Ga gay o o o...!");
	}
	
	@Override
	public void nhap() {
		super.nhap();
	}
	
	@Override
	public void in() {
		System.out.println("Thong tin con ga:");
		super.in();
	}
}
